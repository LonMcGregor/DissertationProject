from django.apps import AppConfig


class NotifyConfig(AppConfig):
    name = 'notify'
