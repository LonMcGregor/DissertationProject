"""This is an empty interface for you
to fill in, according to the coursework"""

def quicksort(input):
    pass