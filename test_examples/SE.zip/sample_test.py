"""This is an empty unit test,
you should fill in your own test cases"""

import unittest as ut
from quicksort import quicksort

class TestQuickSort(ut.TestCase):
    
    def test_one(self):
        result = quicksort([0])
        self.assertTrue(False)