"""This is an empty interface for you
to fill in, according to the coursework"""

class Tree:
    def __init__(self, value):
        pass

    def insert(self, value):
        pass

    def find(self, needle):
        pass
