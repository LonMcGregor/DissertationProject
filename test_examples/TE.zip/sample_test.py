"""This is an empty unit test,
you should fill in your own test cases"""

import unittest as ut
from tree import Tree

class TestTree(ut.TestCase):
    
    def test_one(self):
        my_tree = Tree(4)
        self.assertTrue(False)